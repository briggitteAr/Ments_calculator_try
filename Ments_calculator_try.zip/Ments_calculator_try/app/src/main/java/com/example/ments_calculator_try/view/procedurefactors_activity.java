package com.example.ments_calculator_try.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ments_calculator_try.R;

public class procedurefactors_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_procedurefactors);
    }
}